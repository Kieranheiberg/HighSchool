/*
Shape interface
*/

public interface Shape { //bluebrint for get area and get perimeter methods
   public double getArea();
   public double getPerimeter();
}